#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

typedef struct LstHead
{
    int num;
    struct LstNode *next;
} LstHead;

typedef struct LstNode
{
    char *name;
    char *text;
    int name_len;
    int semi;
    struct LstNode *next;
    struct ArgHead *argHead;
} LstNode;

typedef struct ArgHead
{
    int num;
    struct Arg *next;
} ArgHead;

typedef struct Arg
{
    char *id;
    struct Arg *next;
    char *match;
} Arg;

ArgHead *newArgHead()
{
    ArgHead *argHead = (ArgHead *)malloc(sizeof(ArgHead));
    argHead->num = 0;
    argHead->next = NULL;
}

Arg *newArg(char *id)
{
    Arg *arg = (Arg *)malloc(sizeof(Arg));
    arg->id = id;
    arg->next = NULL;
    arg->match = NULL;
}

LstHead *newLstHead()
{
    LstHead *head = (LstHead *)malloc(sizeof(LstHead));
    head->num = 0;
    head->next = NULL;
}

LstNode *newLstNode()
{
    LstNode *node = (LstNode *)malloc(sizeof(LstNode));
    node->name = NULL;
    node->text = NULL;
    node->next = NULL;
    node->semi = 0;
    node->name_len = 0;
    node->argHead = newArgHead();
    return node;
}

void appendNode(LstHead *head, LstNode *node)
{
    if(head->next == NULL){
        head->next = node;
    }else{
        LstNode *tmp = head->next;
        while(tmp->next != NULL){
            tmp = tmp->next;
        }
        tmp->next = node;
    }
    head->num++;
}

void appendArg(ArgHead *argHead, Arg *arg)
{
    if(argHead->next == NULL){
        argHead->next = arg;
    }else{
        Arg *tmp = argHead->next;
        while(tmp->next != NULL){
            tmp = tmp->next;
        }
        tmp->next = arg;
    }
    argHead->num++;
}

void appendArgId(ArgHead *argHead, char* id)
{
    appendArg(argHead, newArg(id));
}

int checkArg(ArgHead *head, char* id){
    Arg *arg = head->next;
    while(arg != NULL){
        if(!strcmp(arg->id, id)){
            return 1;
        }
        arg = arg->next;
    }
    return 0;
}

void clearMatch(ArgHead *argHead){
    Arg *arg = argHead->next;
    while(arg != NULL){
        arg->match = NULL;
        arg = arg->next;
    }
}

void printfLstNode(LstNode *node)
{
    printf("Name: %s \nText: %s\n", node->name,node->text);
}

void printfArg(Arg *arg)
{
    printf("id: %s\n", arg->id);
}

void printfAll(LstNode *node)
{
    printfLstNode(node);
    if(node->next != NULL){
        printfAll(node->next);
    }
}

void printfAllArg(Arg *arg)
{
    printfArg(arg);
    if(arg->next != NULL){
        printfAllArg(arg->next);
    }
}

void printfLst(LstHead *head)
{
    printfAll(head->next);
}

void printfArgs(ArgHead *argHead)
{
    printfAllArg(argHead->next);
}


// int main()
// {
//     LstHead *head = newLstHead();
//     LstNode *node0 = newLstNode("hello()", "printf(\"hello world\")");
//     LstNode *node1 = newLstNode("test()", "printf(\"test\")");
//     LstNode *node2 = newLstNode("node1()", "printf(\"node1\")");
//     LstNode *node3 = newLstNode("node2()", "printf(\"node2\")");
//     appendNode(head, node0);
//     printfLst(head);
//     appendNode(head, node1);
//     appendNode(head, node2);
//     appendNode(head, node3);
//     printfLst(head);
//     LstNode **lst = getLst(head);
//     printf("%d", head->num);
//     printf("%s", lst[1]->name);
//     printf("END");
// }

// int main()
// {
//     ArgHead *head = newArgHead();
//     printf("%d", head->num);
//     Arg *arg1 = newArg("x");
//     Arg *arg2 = newArg("yz");
//     Arg *arg3 = newArg("xdsf");
//     Arg *arg4 = newArg("fwe");
//     appendArg(head, arg1);
//     appendArg(head, arg2);
//     appendArg(head, arg3);
//     appendArg(head, arg4);
//     printfArgs(head);
//     printf("%d", head->num);
//     if(checkArg(head, "yzds"))
//         printf("REJECT");
// }